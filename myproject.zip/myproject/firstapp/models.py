from django.db import models

class Crime(models.Model):
    id = models.AutoField(primary_key=True)
    case_number = models.CharField(max_length=20, unique=True)
    crime_type = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    date = models.DateField()
    time = models.TimeField()
    description = models.TextField()
    criminal_image = models.ImageField(upload_to='criminal_images/', default='criminal_images/default_criminal.jpg')
    victim_image = models.ImageField(upload_to='victim_images/', default='victim_images/default_victim.jpg')

    def __str__(self):
        return f"Case {self.case_number} - {self.crime_type}"

    class Meta:
        db_table = "CrimeRecord"
