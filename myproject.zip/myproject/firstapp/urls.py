from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

from django.urls import path
from . import views

urlpatterns = [
    path('crime_list/', views.crime_list, name='crime_list'),
    path('add_crime/', views.add_crime, name='add_crime'),
    path('update_crime/<str:case_number>/', views.update_crime, name='update_crime'),
    path('delete_crime/', views.delete_crime),
    # path('crime_report/',views.crime_report)
]

# urlpatterns = [
#     # path('crime/',views.crime),
#     path('crime_list/',views.crime_list),
#     path('add_crime/',views.add_crime),
#     path('update_crime/case_number/', views.update_crime),
#     path('delete_crime/<str:case_number>/', views.delete_crime, name='delete_crime'),
# ]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


