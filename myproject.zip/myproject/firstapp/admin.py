from django.contrib import admin
from .models import Crime

@admin.register(Crime)
class CrimeAdmin(admin.ModelAdmin):
    list_display = ('case_number', 'crime_type', 'location', 'date', 'time','criminal_image','victim_image')
