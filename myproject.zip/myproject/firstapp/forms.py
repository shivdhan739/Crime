# from django import forms
# from .models import Crime, Victim, Criminal




# class CrimeForm(forms.ModelForm):
#     class Meta:
#         model = Crime
#         fields = [
#             'case_number', 'crime_type', 'location', 'date', 'time',
#             'description', 'criminal_image', 'victim_image', 'victim', 'criminal'
#         ]

# from django import forms
# from firstapp.models import Crime

# class CrimeForm(forms.ModelForm):
#     class Meta:
#         model = Crime
#         fields = ('case_number', 'crime_type', 'location', 'date', 'time', 'description')


from django import forms
from .models import Crime

class CrimeForm(forms.ModelForm):
    class Meta:
        model = Crime
        fields = '__all__'
