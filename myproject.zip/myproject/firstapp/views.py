from django.shortcuts import HttpResponse,render, get_object_or_404,redirect
from firstapp.models import Crime  # Import only the model
from .forms import CrimeForm  # Import the form from forms.py
from django.db import connection

# def crime_list(request):
#     crimes = Crime.objects.all()
#     return render(request, 'firstapp/crime_list.html', {'crimes': crimes})

def crime_list(request):
    query = request.GET.get('q')  # Get the search query from the request
    if query:
        crimes = Crime.objects.filter(
            case_number__icontains=query
        ) | Crime.objects.filter(
            crime_type__icontains=query
        ) | Crime.objects.filter(
            location__icontains=query
        )
    else:
        crimes = Crime.objects.all()
    return render(request, 'firstapp/add_crime.html', {'crimes': crimes, 'query': query})

def add_crime(request):
    if request.method == 'POST':
        form = CrimeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse("<h1 style='color:red'>Crime Record added</h1>")
        return redirect('crime_list.html')
    else:
        form = CrimeForm()
    return render(request, 'firstapp/add_crime.html',{'form':form})



from django.shortcuts import get_object_or_404, render
from .forms import CrimeForm
from .models import Crime






from django.shortcuts import render, get_object_or_404, redirect  # Import necessary functions

def update_crime(request, case_number):
    """
    Updates crime data based on the provided case number.

    Args:
        request (HttpRequest): The incoming HTTP request.
        case_number (str): The unique identifier for the crime record.

    Returns:
        HttpResponse: A rendered response depending on the request method.
    """

    crime = get_object_or_404(Crime, case_number=case_number)  # Retrieve crime object or raise 404

    if request.method == 'POST':
        form = CrimeForm(request.POST, request.FILES, instance=crime)  # Populate form with existing data
        if form.is_valid():
            form.save()  # Save updated data
            # Redirect to a success page (modify as needed)
            # return redirect('success_url')  # Replace with appropriate URL pattern name

    else:
        form = CrimeForm(instance=crime)  # Create form with initial data
    if request.method=="GET":
      return render(request, 'firstapp/add_crime.html', {'form': form, 'crime': crime})



def delete_crime(request):

    case_number=request.POST["pid"]

    Crime.objects.filter(case_number=case_number).delete()

    print(connection.queries)

    crime=Crime.objects.all()
    if request.method=="GET":
     return render(request,"firstapp/add_crime.html",{'crime':crime})



























# def delete_crime(request, case_number):
#     """
#     Deletes crime data based on the provided case number.

#     Args:
#         request (HttpRequest): The incoming HTTP request.
#         case_number (str): The unique identifier for the crime record.

#     Returns:
#         HttpResponse: A rendered response depending on the request method.
#     """

#     crime = get_object_or_404(Crime, case_number=case_number)  # Retrieve crime object or raise 404

#     if request.method == 'POST':
#         crime.delete()  # Delete the crime record
#         # Redirect to a confirmation page or list view (modify as needed)
#         # return redirect('crime_list_url')  # Replace with appropriate URL pattern name

#     # Optional confirmation page (customize as needed)
#     return render(request, 'firstapp/add_crime.html')
































# def update_crime(request, case_number):
#     # Retrieve the crime object or return a 404 error
#     crime = get_object_or_404(Crime, case_number=case_number)
    
#     if request.method == 'POST':
#         form = CrimeForm(request.POST, request.FILES, instance=crime)
#         if form.is_valid():
#             form.save()
#             # Redirect or display a success message if needed
#     else:
#         form = CrimeForm(instance=crime)
    
#     return render(request, 'firstapp/add_crime.html', {'form': form, 'crime': crime})

# #Delete crime data
# def delete_crime(request, case_number):
#     # Retrieve the crime object or return 404 if not found
#     crime = get_object_or_404(Crime, case_number=case_number)
    
#     # Handle POST request to confirm deletion
#     if request.method == 'POST':
#         crime.delete()
#         # return redirect('crime_list')  # Redirect after deletion (modify as needed)
    
#     # Render confirmation page (optional)
#     return render(request, 'firstapp/add_crime.html', {'crime': crime})






























































































































# from django.shortcuts import render, redirect
# from firstapp.models import Crime  # Import only the model
# from .forms import CrimeForm  # Import the form from forms.py

# def crime_list(request):
#     crimes = Crime.objects.all()
#     return render(request, 'firstapp/crime_list.html', {'crimes': crimes})

# def add_crime(request):
#     if request.method == 'POST':
#         form = CrimeForm(request.POST, request.FILES)
#         if form.is_valid():
#             form.save()
#             return redirect('crime_list')
#     else:
#         form = CrimeForm()
#     return render(request, 'firstapp/add_crime.html', {'form': form})

# from django.shortcuts import render, redirect
# from .models import Crime
# from .forms import CrimeForm

# def crime_list(request):
#     crimes = Crime.objects.all()
#     return render(request, 'firstapp/crime_list.html', {'crimes': crimes})

# def add_crime(request):
#     if request.method == 'POST':
#         form = CrimeForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('crime_list')
#     else:
#         form = CrimeForm()
#     return render(request, 'firstapp/add_crime.html', {'form': form})

